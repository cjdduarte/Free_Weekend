## Configuration

###days_week [number]
<b>Values:</b> "0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun, -1=Ignore"

###log_tooltip [number]
<b>Values:</b> "0=OFF, 1=Only exceptions, 2=Basic, 3=More details"

###specific_days [string]
<b>Values:</b> ["YYYY/MM/DD", "YYYY/MM/DD"] - <i>Specific days must have quotation marks</i>